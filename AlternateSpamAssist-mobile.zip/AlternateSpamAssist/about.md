# Alternate Spam Assist (Mobile)
Detects when you start spamming taps and takes over with a steady alternate spam.
Android and iOS only.

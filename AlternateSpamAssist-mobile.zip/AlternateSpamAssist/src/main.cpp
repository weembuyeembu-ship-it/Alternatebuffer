#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <deque>
#include <random>
#include <vector>

using namespace geode::prelude;

#if !defined(GEODE_IS_MOBILE)
#error "Alternate Spam Assist is mobile only (Android / iOS)."
#endif

namespace {
    double nowSec() {
        using namespace std::chrono;
        return duration<double>(steady_clock::now().time_since_epoch()).count();
    }
    std::mt19937& rng() {
        static std::mt19937 g{std::random_device{}()};
        return g;
    }
    double rnd(double a, double b) {
        return std::uniform_real_distribution<double>(a, b)(rng());
    }
    template <class T>
    T S(char const* key) {
        return Mod::get()->getSettingValue<T>(key);
    }
}

class $modify(AssistLayer, GJBaseGameLayer) {
    struct Fields {
        std::deque<double> presses;
        double lastPress = -1000.0;
        double realDownSince = 0.0;
        bool realDown = false;

        bool active = false;
        bool phaseDown = false;   // scheduled phase (button should be down)
        int mask = 0;             // which players are actually pressed: 1 = P1, 2 = P2
        bool altTurn = false;
        double nextToggle = 0.0;
        double releaseDur = 0.0;
        double cps = 10.0;
        double driftPhase = rnd(0.0, 6.28318);

        double lockY = 0.0;
        bool lockSet = false;
        double shipI = 0.0;

        bool injecting = false;
        CCLabelBMFont* label = nullptr;
    };

    bool isPlay() {
        return typeinfo_cast<PlayLayer*>(this) != nullptr;
    }

    void inject(bool down, bool p1) {
        auto f = m_fields.self();
        f->injecting = true;
        this->handleButton(down, 1, p1);
        f->injecting = false;
    }

    void releaseMask() {
        auto f = m_fields.self();
        if (f->mask & 1) inject(false, true);
        if (f->mask & 2) inject(false, false);
        f->mask = 0;
    }

    void stopAssist() {
        auto f = m_fields.self();
        if (f->mask) releaseMask();
        f->active = false;
        f->phaseDown = false;
        f->lockSet = false;
        f->shipI = 0.0;
        f->presses.clear();
    }

    // Hand control straight back to the player who is holding the screen.
    void handBack() {
        auto f = m_fields.self();
        if (f->mask) releaseMask();
        f->active = false;
        f->phaseDown = false;
        f->lockSet = false;
        f->presses.clear();
        inject(true, true);
        if (m_gameState.m_isDualMode) inject(true, false);
    }

    void prune(double t) {
        auto f = m_fields.self();
        double window = S<int64_t>("window-ms") / 1000.0;
        while (!f->presses.empty() && t - f->presses.front() > window) f->presses.pop_front();
    }

    bool looksRhythmic() {
        auto f = m_fields.self();
        std::vector<double> iv;
        for (size_t i = 1; i < f->presses.size(); i++) iv.push_back(f->presses[i] - f->presses[i - 1]);
        if (iv.size() < 2) return true;
        double mean = 0;
        for (double v : iv) mean += v;
        mean /= iv.size();
        if (mean <= 0) return false;
        double var = 0;
        for (double v : iv) var += (v - mean) * (v - mean);
        double cv = std::sqrt(var / iv.size()) / mean;
        if (cv > S<double>("consistency")) return false;
        size_t h = iv.size() / 2;
        if (h > 0) {
            double a = 0, b = 0;
            for (size_t i = 0; i < h; i++) a += iv[i];
            for (size_t i = h; i < iv.size(); i++) b += iv[i];
            a /= h;
            b /= (iv.size() - h);
            if (b > a * 1.25) return false; // slowing down
        }
        return true;
    }

    double measuredCps() {
        auto f = m_fields.self();
        if (f->presses.size() < 2) return 0.0;
        double span = f->presses.back() - f->presses.front();
        if (span < 0.01) return 0.0;
        return (f->presses.size() - 1) / span;
    }

    void tryActivate(double t) {
        auto f = m_fields.self();
        if (!m_player1 || m_player1->m_isDead) return;
        prune(t);
        if ((int64_t)f->presses.size() < S<int64_t>("min-clicks")) return;
        double cps = measuredCps();
        if (cps < S<double>("cps-threshold")) return;
        if (S<bool>("smart-detect") && !looksRhythmic()) return;

        f->active = true;
        f->phaseDown = true;                       // the real press is already down
        f->mask = m_gameState.m_isDualMode ? 3 : 1;
        f->altTurn = false;
        f->cps = std::clamp(cps, 3.0, S<double>("max-cps"));
        f->lockSet = false;
        f->shipI = 0.0;
        planCycle(t);
    }

    double currentCps(double t) {
        auto f = m_fields.self();
        double cps;
        if (S<std::string>("mode") == "Fixed") {
            cps = S<double>("fixed-cps");
        } else {
            prune(t);
            double m = measuredCps();
            if (m > 0) f->cps += (m - f->cps) * 0.25;
            cps = f->cps;
        }
        bool ship = m_player1 && m_player1->m_isShip;
        if (S<bool>("humanize") && (!ship || S<bool>("humanize-ship"))) {
            cps += S<double>("humanize-drift") * std::sin(t * 0.9 + f->driftPhase);
        }
        return std::clamp(cps, 1.0, S<double>("max-cps"));
    }

    double shipDuty(double base) {
        auto f = m_fields.self();
        auto p = m_player1;
        double sign = p->m_isUpsideDown ? -1.0 : 1.0;
        if (!f->lockSet) {
            f->lockY = p->getPositionY();
            f->lockSet = true;
            f->shipI = 0.0;
        }
        double err = sign * (f->lockY - p->getPositionY());
        double vel = sign * p->m_yVelocity;
        f->shipI = std::clamp(f->shipI + err * 0.0008, -0.4, 0.4);
        double k = S<double>("ship-correction");
        double d = base + k * (err * 0.012 - vel * 0.02 + f->shipI);
        return std::clamp(d, 0.1, 0.9);
    }

    // Plans hold/release durations for the cycle starting at time t (button going down).
    void planCycle(double t) {
        auto f = m_fields.self();
        double period = 1.0 / currentCps(t);
        double duty = S<int64_t>("duty-cycle") / 100.0;
        bool ship = m_player1 && m_player1->m_isShip;
        if (ship && S<bool>("ship-straight")) duty = shipDuty(0.5);
        double hold = period * duty;
        double rel = period - hold;
        if (S<bool>("humanize") && (!ship || S<bool>("humanize-ship"))) {
            double v = S<double>("humanize-timing") / 100.0;
            hold *= 1.0 + rnd(-v, v);
            rel *= 1.0 + rnd(-v, v);
        }
        f->nextToggle = t + std::max(hold, 0.012);
        f->releaseDur = std::max(rel, 0.012);
    }

    void pressAuto() {
        auto f = m_fields.self();
        bool ship = m_player1 && m_player1->m_isShip;
        if (!ship && S<bool>("humanize") && rnd(0.0, 100.0) < S<double>("humanize-miss")) {
            f->mask = 0; // skipped click
            return;
        }
        bool dual = m_gameState.m_isDualMode;
        int mask = 1;
        if (dual) {
            if (S<bool>("alternate-players")) {
                mask = f->altTurn ? 2 : 1;
                f->altTurn = !f->altTurn;
            } else {
                mask = 3;
            }
        }
        f->mask = mask;
        if (mask & 1) inject(true, true);
        if (mask & 2) inject(true, false);
    }

    void tick(double t) {
        auto f = m_fields.self();
        if (!S<bool>("enabled") || !m_player1 || m_player1->m_isDead) {
            stopAssist();
            return;
        }
        // Player is holding the screen: give control back.
        if (f->realDown && t - f->realDownSince > S<int64_t>("hold-release-ms") / 1000.0) {
            handBack();
            return;
        }
        // Player stopped tapping.
        if (!f->realDown && t - f->lastPress > S<int64_t>("idle-timeout-ms") / 1000.0) {
            stopAssist();
            return;
        }
        int guard = 0;
        while (t >= f->nextToggle && guard++ < 4) {
            if (f->phaseDown) {
                if (f->mask) releaseMask();
                f->phaseDown = false;
                f->nextToggle += f->releaseDur;
            } else {
                double start = f->nextToggle;
                pressAuto();
                f->phaseDown = true;
                planCycle(start);
            }
        }
        if (f->nextToggle < t) f->nextToggle = t;
    }

    void updateIndicator() {
        auto f = m_fields.self();
        auto pl = typeinfo_cast<PlayLayer*>(this);
        if (!pl || !pl->m_uiLayer) return;
        if (!f->label) {
            auto label = CCLabelBMFont::create("Spam Assist", "bigFont.fnt");
            auto win = CCDirector::sharedDirector()->getWinSize();
            label->setScale(0.35f);
            label->setAnchorPoint({0.f, 1.f});
            label->setOpacity(150);
            label->setPosition({6.f, win.height - 6.f});
            label->setID("spam-assist-indicator"_spr);
            pl->m_uiLayer->addChild(label, 100);
            f->label = label;
        }
        f->label->setVisible(f->active && S<bool>("show-indicator"));
    }

    void handleButton(bool down, int button, bool p1) {
        auto f = m_fields.self();
        if (f->injecting || button != 1 || !isPlay()) {
            GJBaseGameLayer::handleButton(down, button, p1);
            return;
        }
        if (!S<bool>("enabled")) {
            if (f->active) stopAssist();
            GJBaseGameLayer::handleButton(down, button, p1);
            return;
        }

        double t = nowSec();
        if (down) {
            if (t - f->lastPress > 0.008) { // ignore the duplicate event from dual mode
                f->lastPress = t;
                f->presses.push_back(t);
            }
            f->realDown = true;
            f->realDownSince = t;
        } else {
            f->realDown = false;
        }

        if (f->active) return; // assist is in control: swallow real input

        GJBaseGameLayer::handleButton(down, button, p1);
        if (down) tryActivate(t);
    }

    void update(float dt) {
        auto f = m_fields.self();
        if (f->active && isPlay()) tick(nowSec());
        GJBaseGameLayer::update(dt);
        updateIndicator();
    }
};

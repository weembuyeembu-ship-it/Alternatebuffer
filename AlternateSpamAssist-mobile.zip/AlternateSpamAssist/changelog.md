# v1.0.0
- Mobile-only rewrite (Android + iOS). Keyboard/keybind features removed.
